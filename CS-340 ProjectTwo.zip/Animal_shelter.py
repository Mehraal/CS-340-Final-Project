from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for animal collection in MongoDB """
    
    def __init__(self, username, password):
        #Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database,the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection variables
        #
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30451
        DB ='AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
# Complete this create methodto imploement the C in CRUD.
    def create(self, data):
       if data is not None:
          insert = self.database.animals.insert_one(data)  #data should be dictionary
          if (insert != 0):
                return True;
          else: 
                return False; 
                
       else :
           raise Exception("Nothing to save, because data parameter is empty")
            
# Create method to implement the R in CRUD.
    def read(self, criteria=None):
        if criteria is not None:
            data = self.database.animals.find(criteria)
        else:
            data = self.database.animals.find({})
             
        return data
        
# Create method to implement the U in CRUD. 
    def update(self, searchData, updateData):
      if searchData is not None:
          result = self.database.animals.update_many(searchData,{"$set": updateData})
                  
      else:
          return "{}"
      return result.raw_result
  # Create method to implement the D in CRUD.              
    def delete(self, deleteData):
        if deleteData is not None:
            if deleteData:
                result = self.database.animals.delete_many(deleteData)
            return result   
        else: 
           raise Exception("Nothing to delete")
